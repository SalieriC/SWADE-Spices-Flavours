## Authors

### Image and Assets

- Squared paper background: [Background photo created by kues](https://www.freepik.com/photos/background)